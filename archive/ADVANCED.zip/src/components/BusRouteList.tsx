import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Bus, Clock, Users, AlertCircle, Search, Info } from 'lucide-react';
import bmtcApi, { BMTCRoute } from '../services/bmtcApi';
import otherBusApi, { OtherRoute } from '../services/otherBusApi';
import { busApi } from '../services/api';
import { generateMockRoutes } from '../services/mockData';
import RouteDetailsModal from './RouteDetailsModal';

interface BusRouteListProps {
  onRouteSelect: (routeId: string) => void;
  selectedRoute: string | null;
  showAll?: boolean;
  searchQuery?: string;
  filters?: {
    providers: string[];
    crowdLevels: string[];
    routeTypes: string[];
  };
}

type RouteWithProvider = (BMTCRoute | OtherRoute) & {
  provider: string;
  frequency: string;
  status: string;
  crowdLevel: string;
  crowdPercentage: number;
  nextBus: string;
};

const BusRouteList: React.FC<BusRouteListProps> = ({ 
  onRouteSelect, 
  selectedRoute, 
  showAll = false,
  searchQuery: propSearchQuery = '',
  filters: propFilters
}) => {
  const { t } = useTranslation();
  const [routes, setRoutes] = useState<RouteWithProvider[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState(propSearchQuery);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [refreshInterval, setRefreshInterval] = useState<ReturnType<typeof setInterval> | null>(null);
  const [usingFallbackData, setUsingFallbackData] = useState(false);
  const [showRouteDetails, setShowRouteDetails] = useState<RouteWithProvider | null>(null);

  useEffect(() => {
    let isMounted = true;
    
    const fetchRoutes = async () => {
      if (!isMounted) return;
      
      setLoading(true);
      setError(null);
      
      try {
        // Use the unified API to fetch all routes
        const allRoutes = await busApi.getAllRoutes();
        
        if (!isMounted) return;
        
        // Enhance routes with additional info (stable random values)
        const enhancedRoutes = allRoutes.map((route, index) => {
          const provider = route.provider || (
            route.id.startsWith('bmtc-') ? 'BMTC' : 
            route.id.startsWith('ksrtc-') ? 'KSRTC' : 
            route.id.startsWith('apsrtc-') ? 'APSRTC' : 
            route.id.startsWith('tnstc-') ? 'TNSTC' : 
            route.id.startsWith('best-') ? 'BEST' : 
            route.id.startsWith('dtc-') ? 'DTC' : 'Unknown'
          );
          
          // Use index for stable random values to prevent constant changes
          const crowdLevels = ['Low', 'Medium', 'High'];
          const statuses = ['On time', 'Slight delay', 'Delayed'];
          const crowdLevel = crowdLevels[index % 3];
          const status = statuses[index % 3];
          
          // Generate stable crowd percentage based on crowd level
          let crowdPercentage: number;
          if (crowdLevel === 'Low') {
            crowdPercentage = 20 + (index % 20); // 20-39%
          } else if (crowdLevel === 'Medium') {
            crowdPercentage = 45 + (index % 20); // 45-64%
          } else {
            crowdPercentage = 75 + (index % 20); // 75-94%
          }
          
          return {
            ...route,
            provider,
            frequency: route.frequency || `${5 + (index % 10)} min`,
            status: status,
            crowdLevel: crowdLevel,
            crowdPercentage: crowdPercentage,
            nextBus: `${1 + (index % 15)} min`
          };
        });
        
        if (isMounted) {
          setRoutes(enhancedRoutes);
          setUsingFallbackData(false);
        }
      } catch (err) {
        console.error('Error fetching routes:', err);
        
        if (!isMounted) return;
        
        setError('Failed to load routes. Using fallback data.');
        setUsingFallbackData(true);
        
        // Use the generateMockRoutes function defined below
        const mockRoutes = createMockRoutes(15);
        if (isMounted) {
          setRoutes(mockRoutes);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };
    
    fetchRoutes();
    
    // Set up interval to refresh route data every 2 minutes (less frequent to reduce blinking)
    const intervalId = setInterval(fetchRoutes, 120000);
    
    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []); // Empty dependency array to prevent re-running

  // Generate mock routes as a last resort
  const generateMockRoutes = (count: number): RouteWithProvider[] => {
    const providers = ['BMTC', 'KSRTC', 'APSRTC', 'TNSTC', 'BEST', 'DTC'];
    const routes: RouteWithProvider[] = [];
    
    for (let i = 0; i < count; i++) {
      const provider = providers[i % providers.length];
      const routeNumber = `${provider.substring(0, 2)}${100 + i}`;
      const crowdLevel = getRandomCrowdLevel();
      
      // Generate crowd percentage based on crowd level
      let crowdPercentage: number;
      if (crowdLevel === 'Low') {
        crowdPercentage = Math.floor(Math.random() * 30) + 10; // 10-40%
      } else if (crowdLevel === 'Medium') {
        crowdPercentage = Math.floor(Math.random() * 30) + 40; // 40-70%
      } else {
        crowdPercentage = Math.floor(Math.random() * 25) + 70; // 70-95%
      }
      
      routes.push({
        id: `${provider.toLowerCase()}-route-${i + 1}`,
        provider,
        routeNumber,
        routeName: `${provider} Route ${i + 1}`,
        source: `${provider} Central`,
        destination: `${provider} Terminal ${i % 5 + 1}`,
        via: `Via ${provider} Junction`,
        frequency: `${Math.floor(Math.random() * 15) + 5} min`,
        stops: [],
        status: getRandomStatus(),
        crowdLevel: crowdLevel,
        crowdPercentage: crowdPercentage,
        nextBus: `${Math.floor(Math.random() * 15) + 1} min`
      });
    }
    
    return routes;
  };

  // Filter routes based on search query and selected provider
  const filteredRoutes = routes.filter(route => {
    const matchesSearch = searchQuery === '' || 
      route.routeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      route.source?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      route.destination?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesProvider = selectedProvider === null || route.provider === selectedProvider;
    
    return matchesSearch && matchesProvider;
  });

  // If not showing all routes, only show the first 5
  const displayedRoutes = showAll ? filteredRoutes : filteredRoutes.slice(0, 5);

  // Function to get crowd level color
  const getCrowdLevelColor = (level: string) => {
    switch (level) {
      case 'Low':
        return 'bg-green-100 text-green-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'High':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper functions for random data
  function getRandomStatus() {
    const statuses = ['On time', 'Slight delay', 'Delayed'];
    return statuses[Math.floor(Math.random() * statuses.length)];
  }

  function getRandomCrowdLevel() {
    const levels = ['Low', 'Medium', 'High'];
    return levels[Math.floor(Math.random() * levels.length)];
  }

  // Get provider badge color
  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'BMTC':
        return 'bg-blue-100 text-blue-800';
      case 'KSRTC':
        return 'bg-purple-100 text-purple-800';
      case 'APSRTC':
        return 'bg-green-100 text-green-800';
      case 'TNSTC':
        return 'bg-yellow-100 text-yellow-800';
      case 'BEST':
        return 'bg-red-100 text-red-800';
      case 'DTC':
        return 'bg-indigo-100 text-indigo-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="overflow-y-auto max-h-[500px]">
      {/* Search and filter */}
      <div className="p-4 border-b">
        <div className="relative mb-3">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder={t('busRouteList.searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button
            className={`text-xs px-2 py-1 rounded-full ${selectedProvider === null ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
            onClick={() => setSelectedProvider(null)}
          >
            {t('busRouteList.allProviders')}
          </button>
          <button
            className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'BMTC' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
            onClick={() => setSelectedProvider('BMTC')}
          >
            BMTC
          </button>
          <button
            className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'KSRTC' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
            onClick={() => setSelectedProvider('KSRTC')}
          >
            KSRTC
          </button>
          <button
            className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'APSRTC' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
            onClick={() => setSelectedProvider('APSRTC')}
          >
            APSRTC
          </button>
          {showAll && (
            <>
              <button
                className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'TNSTC' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                onClick={() => setSelectedProvider('TNSTC')}
              >
                TNSTC
              </button>
              <button
                className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'BEST' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                onClick={() => setSelectedProvider('BEST')}
              >
                BEST
              </button>
              <button
                className={`text-xs px-2 py-1 rounded-full ${selectedProvider === 'DTC' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
                onClick={() => setSelectedProvider('DTC')}
              >
                DTC
              </button>
            </>
          )}
        </div>
      </div>

      {loading ? (
        <div className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">{t('busRouteList.loadingRoutes')}</p>
        </div>
      ) : error ? (
        <div className="p-4 bg-yellow-50 text-yellow-700">
          <AlertCircle className="h-5 w-5 text-yellow-500 mb-2 mx-auto" />
          <p className="text-center">{error}</p>
          <div className="mt-4">
            <p className="text-xs text-center text-gray-600">{t('busRouteList.fallbackDataNotice')}</p>
          </div>
        </div>
      ) : displayedRoutes.length === 0 ? (
        <div className="p-8 text-center">
          <p className="text-gray-600">{t('busRouteList.noRoutesFound')}</p>
        </div>
      ) : (
        <>
          <ul className="divide-y divide-gray-200">
            {displayedRoutes.map((route) => (
              <li
                key={route.id}
                className={`hover:bg-gray-50 cursor-pointer transition ${selectedRoute === route.id ? 'bg-blue-50' : ''}`}
                onClick={() => onRouteSelect(route.id)}
              >
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1 min-w-0">
                      <div className={`flex-shrink-0 h-12 w-12 rounded-full flex items-center justify-center text-sm font-bold ${
                        route.provider === 'BMTC' ? 'bg-blue-100 text-blue-800' :
                        route.provider === 'KSRTC' ? 'bg-purple-100 text-purple-800' :
                        route.provider === 'APSRTC' ? 'bg-green-100 text-green-800' :
                        route.provider === 'TNSTC' ? 'bg-yellow-100 text-yellow-800' :
                        route.provider === 'BEST' ? 'bg-red-100 text-red-800' :
                        route.provider === 'DTC' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {route.routeNumber?.substring(0, 3) || route.provider.substring(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-base font-semibold text-gray-900 truncate">
                            {route.routeName || `${route.provider} ${route.routeNumber}`}
                          </h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 font-medium ${getProviderColor(route.provider)}`}>
                            {route.provider}
                          </span>
                        </div>
                        <div className="space-y-1 text-sm text-gray-600">
                          <div className="flex items-center">
                            <span className="font-medium text-gray-700 mr-2">From:</span>
                            <span className="truncate">{route.source}</span>
                          </div>
                          <div className="flex items-center">
                            <span className="font-medium text-gray-700 mr-2">To:</span>
                            <span className="truncate">{route.destination}</span>
                          </div>
                          {route.via && (
                            <div className="flex items-center">
                              <span className="font-medium text-gray-700 mr-2">Via:</span>
                              <span className="truncate text-gray-500">{route.via}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2 flex-shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowRouteDetails(route);
                        }}
                        className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                        title="View detailed route information"
                      >
                        <Info className="h-4 w-4" />
                      </button>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        route.status === 'On time' ? 'bg-green-100 text-green-800' :
                        route.status === 'Slight delay' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {route.status}
                      </span>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCrowdLevelColor(route.crowdLevel)}`}>
                        {route.crowdLevel}
                      </span>
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    {/* Timing Information */}
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="flex-shrink-0 mr-2 h-4 w-4 text-gray-400" />
                        <span className="font-medium">Every {route.frequency}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Bus className="flex-shrink-0 mr-2 h-4 w-4 text-blue-500" />
                        <span className="text-gray-700">
                          <span className="font-medium">Next:</span> {route.nextBus}
                        </span>
                      </div>
                    </div>

                    {/* Crowd Information */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-gray-600">
                          <Users className="flex-shrink-0 mr-2 h-4 w-4 text-gray-400" />
                          <span className="font-medium">Occupancy</span>
                        </div>
                        <span className="text-sm font-semibold text-gray-700">{route.crowdPercentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ease-out ${
                            route.crowdPercentage <= 40 ? 'bg-gradient-to-r from-green-400 to-green-500' :
                            route.crowdPercentage <= 70 ? 'bg-gradient-to-r from-yellow-400 to-yellow-500' :
                            'bg-gradient-to-r from-red-400 to-red-500'
                          }`}
                          style={{ width: `${Math.min(route.crowdPercentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
          {!showAll && routes.length > 5 && (
            <div className="px-4 py-3 bg-gray-50 text-center">
              <button
                onClick={() => onRouteSelect('all')}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                {t('busRouteList.viewAllRoutes', { count: routes.length })}
              </button>
            </div>
          )}
        </>
      )}

      {/* Real-time indicator */}
      <div className="px-4 py-2 bg-gray-50 border-t flex items-center justify-center">
        <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
        <span className="text-xs text-gray-600">
          {usingFallbackData ? t('busRouteList.simulatedData') : t('busRouteList.liveData')} • {t('busRouteList.autoRefreshes')}
        </span>
      </div>
      
      {/* Route Details Modal */}
      {showRouteDetails && (
        <RouteDetailsModal
          route={showRouteDetails}
          onClose={() => setShowRouteDetails(null)}
        />
      )}
    </div>
  );
};

export default BusRouteList;
