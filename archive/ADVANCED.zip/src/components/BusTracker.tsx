import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, MapPin, Clock, Route, Navigation, AlertCircle, RefreshCw, X, Bus, TrendingUp } from 'lucide-react';
import { busApi, subscribeToUpdates, socketEvents } from '../services/backendApi';
import { toast } from 'react-hot-toast';
import BusRouteMap from './BusRouteMap';

interface BusSearchResult {
  id: string;
  bus_number: string;
  route_id: string;
  route_name: string;
  route_number: string;
  current_lat: number;
  current_lng: number;
  speed: number;
  crowd_level: string;
  crowd_percentage: number;
  city: string;
  source: string;
  destination: string;
}

interface CurrentStop {
  id?: string;
  name: string;
  latitude: number;
  longitude: number;
  distance: number;
  isAtStop: boolean;
}

interface UpcomingStop {
  name: string;
  latitude: number;
  longitude: number;
  distance: number;
  eta: number;
  etaFormatted: string;
}

const BusTracker: React.FC = () => {
  const { t } = useTranslation();
  const [busNumber, setBusNumber] = useState('');
  const [searchResults, setSearchResults] = useState<BusSearchResult[]>([]);
  const [selectedBus, setSelectedBus] = useState<BusSearchResult | null>(null);
  const [currentStop, setCurrentStop] = useState<CurrentStop | null>(null);
  const [upcomingStops, setUpcomingStops] = useState<UpcomingStop[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');
  const [isTracking, setIsTracking] = useState(false);

  // Search for bus by number
  const handleSearch = async () => {
    if (!busNumber.trim()) {
      toast.error('Please enter a bus number');
      return;
    }

    setLoading(true);
    setError(null);
    setSelectedBus(null);

    try {
      const response = await busApi.searchBusByNumber(busNumber.trim());
      if (response.data.success && response.data.data.length > 0) {
        setSearchResults(response.data.data);
        if (response.data.data.length === 1) {
          // Auto-select if only one result
          handleSelectBus(response.data.data[0]);
        }
      } else {
        setError('Bus not found. Please check the bus number.');
        setSearchResults([]);
      }
    } catch (err: any) {
      console.error('Error searching bus:', err);
      setError(err.response?.data?.message || 'Failed to search bus. Please try again.');
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  };

  // Select a bus and start tracking
  const handleSelectBus = async (bus: BusSearchResult) => {
    setSelectedBus(bus);
    setSearchResults([]);
    setIsTracking(true);
    
    // Fetch current stop and upcoming stops
    await fetchBusDetails(bus.id);
    
    // Ensure socket is connected before subscribing
    const { socket, connectSocket } = await import('../services/backendApi');
    if (!socket.connected) {
      connectSocket();
      // Wait a bit for connection
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Subscribe to real-time updates
    subscribeToUpdates.subscribeToBus(bus.id);
  };

  // Fetch current stop and upcoming stops
  const fetchBusDetails = async (busId: string) => {
    try {
      // Fetch current stop
      const currentStopResponse = await busApi.getBusCurrentStop(busId);
      if (currentStopResponse.data.success) {
        setCurrentStop(currentStopResponse.data.data.currentStop);
        setStatus(currentStopResponse.data.data.status);
      }

      // Fetch upcoming stops
      const upcomingStopsResponse = await busApi.getBusUpcomingStops(busId);
      if (upcomingStopsResponse.data.success) {
        setUpcomingStops(upcomingStopsResponse.data.data.upcomingStops);
      }
    } catch (err: any) {
      console.error('Error fetching bus details:', err);
      toast.error('Failed to fetch bus details');
    }
  };

  // Handle real-time updates
  useEffect(() => {
    if (!selectedBus) return;

    const unsubscribe = socketEvents.onBusLocationUpdate((data: any) => {
      if (data.busId === selectedBus.id) {
        // Update bus location
        setSelectedBus(prev => prev ? {
          ...prev,
          current_lat: data.location?.lat || prev.current_lat,
          current_lng: data.location?.lng || prev.current_lng,
          speed: data.speed || prev.speed,
          crowd_level: data.crowdLevel || prev.crowd_level,
          crowd_percentage: data.crowdPercentage || prev.crowd_percentage
        } : null);

        // Refresh bus details periodically
        fetchBusDetails(selectedBus.id);
      }
    });

    // Refresh every 10 seconds
    const interval = setInterval(() => {
      fetchBusDetails(selectedBus.id);
    }, 10000);

    return () => {
      unsubscribe();
      clearInterval(interval);
      subscribeToUpdates.unsubscribe(`bus:${selectedBus.id}`);
    };
  }, [selectedBus]);

  // Handle Enter key in search
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleClear = () => {
    setBusNumber('');
    setSelectedBus(null);
    setSearchResults([]);
    setCurrentStop(null);
    setUpcomingStops([]);
    setIsTracking(false);
    setError(null);
  };

  const getCrowdColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'High': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'At Station': return 'bg-green-500';
      case 'Approaching Station': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 py-6">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            🚌 Where is My Bus?
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            Track your bus in real-time by entering the bus number
          </p>
        </div>

        {/* Search Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Bus className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-10 py-3 border border-gray-300 dark:border-gray-600 rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                placeholder="Enter bus number (e.g., KA-01-AB-1234 or 1234)"
                value={busNumber}
                onChange={(e) => setBusNumber(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={loading || isTracking}
              />
              {busNumber && (
                <button
                  onClick={() => setBusNumber('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  <X className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                </button>
              )}
            </div>
            <button
              onClick={handleSearch}
              disabled={loading || isTracking}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <RefreshCw className="h-5 w-5 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="h-5 w-5" />
                  Search
                </>
              )}
            </button>
            {selectedBus && (
              <button
                onClick={handleClear}
                className="px-6 py-3 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
              >
                Clear
              </button>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
              <p className="text-red-600 dark:text-red-400">{error}</p>
            </div>
          )}

          {/* Search Results */}
          {searchResults.length > 0 && !selectedBus && (
            <div className="mt-4 space-y-2">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                Found {searchResults.length} bus(es):
              </p>
              {searchResults.map((bus) => (
                <div
                  key={bus.id}
                  onClick={() => handleSelectBus(bus)}
                  className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-lg text-gray-900 dark:text-white">
                        {bus.bus_number}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {bus.route_name} ({bus.route_number})
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                        {bus.source} → {bus.destination}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCrowdColor(bus.crowd_level)}`}>
                        {bus.crowd_level} ({bus.crowd_percentage}%)
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bus Tracking Section */}
        {selectedBus && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Bus Info & Status */}
            <div className="lg:col-span-1 space-y-6">
              {/* Current Status Card */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                  <Navigation className="h-6 w-6 text-blue-500" />
                  Current Status
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Bus Number</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{selectedBus.bus_number}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Route</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{selectedBus.route_name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500">{selectedBus.route_number}</p>
                  </div>

                  {currentStop && (
                    <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                      <div className="flex items-start gap-3">
                        <MapPin className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">Current Location</p>
                          <p className="font-semibold text-gray-900 dark:text-white">{currentStop.name}</p>
                          {!currentStop.isAtStop && (
                            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                              {currentStop.distance}m away
                            </p>
                          )}
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(status)} text-white`}>
                          {status}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Speed</p>
                      <p className="text-lg font-semibold text-gray-900 dark:text-white">
                        {selectedBus.speed.toFixed(1)} km/h
                      </p>
                    </div>
                    <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Crowd Level</p>
                      <p className={`text-lg font-semibold ${getCrowdColor(selectedBus.crowd_level).split(' ')[1]}`}>
                        {selectedBus.crowd_percentage}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Upcoming Stops Card */}
              {upcomingStops.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                    <Clock className="h-6 w-6 text-green-500" />
                    Upcoming Stops
                  </h3>
                  
                  <div className="space-y-3">
                    {upcomingStops.map((stop, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                      >
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 dark:text-white">{stop.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                            {stop.distance}m away
                          </p>
                        </div>
                        <div className="flex-shrink-0 text-right">
                          <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                            {stop.etaFormatted}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Map */}
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div className="p-4 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-500" />
                    Live Location Map
                  </h3>
                </div>
                <div className="h-[600px]">
                  {selectedBus && (
                    <BusRouteMap
                      selectedRoute={selectedBus.route_id}
                      onStopSelect={() => {}}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!selectedBus && !loading && !error && busNumber === '' && (
          <div className="text-center py-12">
            <Bus className="h-24 w-24 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400 text-lg">
              Enter a bus number above to start tracking
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BusTracker;

